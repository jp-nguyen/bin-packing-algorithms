#! /bin/bash

make && ./proj2
